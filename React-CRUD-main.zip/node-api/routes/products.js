var express = require('express');
var router = express.Router();
var productController = require('../controller/product')

router.post('/', productController.add);
router.get('/', productController.get);
router.get('/:id', productController.getProduct);
router.put('/:id', productController.updateProduct);
router.delete('/:id', productController.deleteProduct);

module.exports = router;
         