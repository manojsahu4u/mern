const Product = require("../model/product");

exports.add = async(req, res) => {
    const products  = new Product(req.body);
    await products.save();
    res.send("Product Create Successfully")
}

exports.get = async(req, res) => {
    productData = await Product.find().select('title image');
    res.json(productData);
}

exports.getProduct = async(req, res) => {
    id = req.params.id;
    console.log(id);
    productData = await Product.findOne({_id: id}).select('title image');
    res.json(productData);
}

exports.updateProduct = async(req, res) => {
    id = req.params.id;
    title = req.body.title;
    image = req.body.image;
    productData = await Product.updateOne({_id: id},{$set: {title: title, image: image}});
    res.json(productData);
}

exports.deleteProduct = async(req, res) => {
    id = req.params.id;
    console.log(id);
    productData = await Product.remove({_id: id});
    res.json(productData);
}