module.exports =  {
    'secret':'nodeauthsecret',
    'database': process.env.NODE_ENV == 'test' ? 'mongodb://localhost:27017/ssi' : 'mongodb://localhost:27017/ssi',
    'options': { useNewUrlParser: true, useUnifiedTopology: true }
  };