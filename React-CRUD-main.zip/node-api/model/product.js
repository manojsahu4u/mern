const mongoose = require('mongoose');
const conn = require('../config/db')

mongoose.connect(conn.database, conn.options);
const Schema = mongoose.Schema;

const ProductSchema = new Schema({
    title: {type: String, default: ''},
    image: {type: String, default: ''}
},{
    timestamps: {createdAt: "created_at", updateAt: "updated_at"}
})

const productModel = mongoose.model('Product', ProductSchema);
module.exports = productModel;

